پریست «حال و هوای پاییزی» — بدون روتوش
------------------------------------------------------------
Autumn-golden colour grade — NO retouching

• ۱۱ عکس، خروجی دقیقاً با همان ابعاد و کیفیت ورودی: 6240 × 4160 پیکسل (26 مگاپیکسل)
• 11 photos, output resolution identical to the input: 6240 x 4160 px (26 MP)
• JPEG کیفیت 94، نمونه‌برداری رنگ 4:4:4 (بدون زیرنمونه‌برداری)
• JPEG quality 94, chroma subsampling 4:4:4 (no chroma subsampling)
• متادیتای EXIF / DPI اصلی حفظ شده است
• Original EXIF / DPI metadata preserved

چه کاری انجام شده (فقط تنظیم رنگ، هیچ روتوشی نشده):
- وایت‌بالانس ساعت طلایی (highlights گرم، سایه‌ها کمی خنثی)
- Curve فیلمی با سیاه‌های کمی بالا آمده و شانه‌ی نرم برای هایلایت‌ها
- رنگ انتخابی: سبزهای باقی‌مانده به طلایی پاییزی، نارنجی/زرد پررنگ‌تر، قرمزها کنترل‌شده
- گلو نرم روی هایلایت‌ها + clarity در میدتون‌ها
- وینیت ملایم و دانه‌ی خیلی کم برای حس فیلمی
- شارپ خروجی ملایم، محافظت‌شده در هایلایت‌ها
- تنظیم اختصاصی رنگ پوست افراد: تُن پوست طبیعی و گرم، قرمزی اضافی کنترل،
  سایه‌های صورت کمی روشن‌تر، بدون گلو/شارپ اضافه روی صورت
  (پوست به‌صورت خودکار تشخیص داده می‌شود؛ برگ‌های طلایی با آن اشتباه گرفته نمی‌شوند)

What was done (colour only — nothing retouched):
- golden-hour white balance
- filmic S-curve, lifted blacks, soft highlight shoulder
- selective colour: greens pulled to autumn gold, oranges/yellows lifted, reds tamed
- gentle highlight bloom + mid-tone clarity
- soft vignette and a hint of filmic grain
- fine output sharpening, protected in the highlights
- dedicated skin-tone treatment for the people: natural warm skin, redness kept in
  check, small shadow fill, no bloom / no extra sharpening on faces
  (skin is detected automatically, so golden leaves are not mistaken for skin)

فایل‌ها / Files:
  IMG_xxxx_autumn.jpg   نسخه‌ی گریدشده‌ی هر عکس / graded version of each photo
  preview_all.jpg       کانتکت‌شیت همه‌ی خروجی‌ها / contact sheet of all outputs

اسکریپت / Script:  tools/autumn_grade.py  (repo: eternity-lord/ai-enhancer)
  python3 tools/autumn_grade.py --batch SRC_DIR OUT_DIR --quality 96
